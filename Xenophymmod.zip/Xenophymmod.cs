using Terraria.ModLoader;

namespace Xenophymmod
{
	public class Xenophymmod : Mod
	{
		public Xenophymmod()
		{
		}
	}
}