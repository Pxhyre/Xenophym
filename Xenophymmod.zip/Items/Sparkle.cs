﻿namespace ExampleMod.Projectiles
{
    internal class Sparkle
    {
    }
}