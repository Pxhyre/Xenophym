using Terraria.ID;
using Terraria.ModLoader;

namespace Xenophymmod.Items.Weapons
{
	public class ExampleSwordIGuess : ModItem
	{
		public override void SetStaticDefaults() 
		{
			 DisplayName.SetDefault("Fiery Sword"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("The power of The Underworld lies in this sword.");
		}

		public override void SetDefaults() 
		{
			item.damage = 30;
			item.crit = 5;
			item.melee = true;
			item.width = 20;
			item.height = 10;
			item.useTime = 22;
			item.useAnimation = 22;
			item.useStyle = 1;
			item.knockBack = 2;
			item.value = 10000;
			item.rare = 3;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
		}

		public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.HellstoneBar, 15);
			recipe.AddIngredient(ItemID.Obsidian, 30);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddIngredient(this);
			recipe.AddRecipe();
		}
	}
}