﻿using Xenophymmod.Projectiles;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Xenophymmod.Items.Weapons
{
	public class SpearOfTheGods : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("Uses the power of cosmos to make itself indestructible.");
		}

		public override void SetDefaults()
		{
			item.damage = 215;
			item.useStyle = 5;
			item.useAnimation = 18;
			item.useTime = 22;
			item.shootSpeed = 3.9f;
			item.knockBack = 8f;
			item.width = 38;
			item.height = 40;
			item.scale = 1.2f;
			item.rare = 10;
			item.value = Item.sellPrice(gold: 25);

			item.melee = true;
			item.noMelee = true; // Important because the spear is actually a projectile instead of an item. This prevents the melee hitbox of this item.
			item.noUseGraphic = true; // Important, it's kind of wired if people see two spears at one time. This prevents the melee animation of this item.
			item.autoReuse = true; // Most spears don't autoReuse, but it's possible when used in conjunction with CanUseItem()

			item.UseSound = SoundID.Item1;
			item.shoot = ProjectileType<ExampleSpearProjectile>();
		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FragmentSolar, 12);
			recipe.AddIngredient(ItemID.FragmentNebula, 12); 
			recipe.AddIngredient(ItemID.FragmentStardust, 12);
			recipe.AddIngredient(ItemID.FragmentVortex, 12);
			recipe.AddIngredient(ItemID.LunarBar, 10);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		public override bool CanUseItem(Player player)
		{
			// Ensures no more than one spear can be thrown out, use this when using autoReuse
			return player.ownedProjectileCounts[item.shoot] < 1;
		}
	}
}