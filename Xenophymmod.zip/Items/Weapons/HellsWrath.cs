﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Xenophymmod.Items.Weapons
{
	public class HellsWrath : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hell's Wrath"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("Within this sword lies a fragment of Satan himself.");
		}

		public override void SetDefaults()
		{
			item.damage = 62;
			item.crit = 8;
			item.melee = true;
			item.width = 20;
			item.height = 10;
			item.scale = 1.2f;
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.knockBack = 8;
			item.value = Item.sellPrice(gold: 1);
			item.rare = 4;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(mod.ItemType("ExampleSwordIGuess"), 1);
			recipe.AddIngredient(ItemID.AdamantiteBar, 15);
			recipe.AddTile(TileID.DemonAltar);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}